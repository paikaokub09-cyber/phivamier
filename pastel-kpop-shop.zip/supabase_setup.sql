-- 1. สร้างตารางตั้งค่าร้านค้า (Store Settings)
CREATE TABLE store_settings (
  id INT PRIMARY KEY DEFAULT 1,
  store_name TEXT DEFAULT 'Pastel K-Pop Shop 🌸',
  store_desc TEXT DEFAULT 'ร้านขายการ์ดและอัลบั้มศิลปิน นำเข้าจากเกาหลี 100%',
  contact_info TEXT DEFAULT '@pastel_shop',
  logo_url TEXT DEFAULT '',
  banner_url TEXT DEFAULT 'https://images.unsplash.com/photo-1618005182384-a83a8bd57fbe?auto=format&fit=crop&w=1200&q=80',
  qr_url TEXT DEFAULT '',
  discord_webhook TEXT DEFAULT '',
  shipping_reg INT DEFAULT 35,
  shipping_ems INT DEFAULT 50
);

INSERT INTO store_settings (id) VALUES (1) ON CONFLICT DO NOTHING;

-- 2. สร้างตารางสินค้า (Products)
CREATE TABLE products (
  id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
  name TEXT NOT NULL,
  price INT NOT NULL,
  stock INT NOT NULL DEFAULT 0,
  description TEXT,
  image_url TEXT,
  created_at TIMESTAMPTZ DEFAULT NOW()
);

-- 3. สร้างตารางคำสั่งซื้อ (Orders)
CREATE TABLE orders (
  id TEXT PRIMARY KEY,
  account_x TEXT NOT NULL,
  customer_name TEXT NOT NULL,
  phone TEXT NOT NULL,
  address TEXT NOT NULL,
  items JSONB NOT NULL,
  shipping_method TEXT NOT NULL,
  shipping_cost INT NOT NULL,
  total_price INT NOT NULL,
  slip_url TEXT,
  status TEXT DEFAULT 'รอตรวจสอบการชำระเงิน',
  courier TEXT DEFAULT '',
  tracking_number TEXT DEFAULT '',
  created_at TIMESTAMPTZ DEFAULT NOW()
);

-- 4. สร้าง Storage Bucket สำหรับเก็บรูปสินค้า สลิป และโลโก้
INSERT INTO storage.buckets (id, name, public) VALUES ('shop-images', 'shop-images', true) ON CONFLICT DO NOTHING;

-- 5. เปิดสิทธิ์การเข้าถึง (RLS Policies)
ALTER TABLE store_settings ENABLE ROW LEVEL SECURITY;
ALTER TABLE products ENABLE ROW LEVEL SECURITY;
ALTER TABLE orders ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Public read settings" ON store_settings FOR SELECT USING (true);
CREATE POLICY "Admin update settings" ON store_settings FOR UPDATE USING (auth.role() = 'authenticated');

CREATE POLICY "Public read products" ON products FOR SELECT USING (true);
CREATE POLICY "Admin all products" ON products FOR ALL USING (auth.role() = 'authenticated');
CREATE POLICY "Public update stock" ON products FOR UPDATE USING (true);

CREATE POLICY "Public insert orders" ON orders FOR INSERT WITH CHECK (true);
CREATE POLICY "Public read orders" ON orders FOR SELECT USING (true);
CREATE POLICY "Admin update orders" ON orders FOR UPDATE USING (auth.role() = 'authenticated');

CREATE POLICY "Public read images" ON storage.objects FOR SELECT USING (bucket_id = 'shop-images');
CREATE POLICY "Public upload images" ON storage.objects FOR INSERT WITH CHECK (bucket_id = 'shop-images');
